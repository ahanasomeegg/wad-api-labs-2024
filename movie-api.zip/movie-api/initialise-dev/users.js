const  users = [
    {
        'username': 'user1',
        'password': 'test123@',
    },
    {
        'username': 'user2',
        'password': 'test456@',
    },
];
export default users;